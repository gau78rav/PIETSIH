<?php

    $dbhost="localhost";
    $dbuser="root";
    $dbpass="";
    $db="sih";
    $conn = mysqli_connect($dbhost,$dbuser,$dbpass,$db) or die("Connection failed");
?>