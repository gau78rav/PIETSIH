<?php

/* Google App Client Id */
define('CLIENT_ID', '595681862707-vset6c8d7tgnd12qijo0k7h8hb5lohs1.apps.googleusercontent.com');

/* Google App Client Secret */
define('CLIENT_SECRET', 'oXZnS-yqpEIOh7HIfbru-5Vk');

/* Google App Redirect Url */
define('CLIENT_REDIRECT_URL', 'http://localhost/9-1/G_gauth.php');

?>